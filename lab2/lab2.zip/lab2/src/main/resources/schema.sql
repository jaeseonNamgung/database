create schema school;
create table backup_student
(
    student_id varchar(50) primary key,
    student_name varchar(50) not null,
    gender varchar(50) not null,
    class_name varchar(50) not null,
    dNumber varchar(50) not null,
    college_name varchar(50) not null,
    major_name varchar(50) not null
);

delimiter $$
create trigger student_deleteTrg
    after delete
    on student
    for each row
    begin
        insert into backup_student (
            select student_id, student_name  ,gender,
                   class_name , dormitory_number ,
                   college_name, major_name
            from student s join class c on s.class_id= c.class_id
                           join dormitory d on s.dormitory_id = d.dormitory_id
                           join college co on s.college_id = co.college_id join major m
                           on s.major_id = m.major_id where s.student_id = old.student_id
        );
    end $$
delimiter ;

