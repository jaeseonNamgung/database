const bttn = document.querySelector("button");
const fc1 = document.querySelector(".input1");
const fc2 = document.querySelector(".input2");
const fc3 = document.querySelector(".input3");
const fc4 = document.querySelector(".input4");
const fc5 = document.querySelector(".input5");
const fc6 = document.querySelector(".input6");
const fc7 = document.querySelector(".input7");

bttn.onclick = (e) => {

  if(fc1.value === "" || fc2.value === "" || fc3.value === "" || fc4.value === "" || fc5.value === "" || fc6.value === "" || fc7.value === "") {
    e.preventDefault();
    location.reload();
    alert("空值")
  }
}