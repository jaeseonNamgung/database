package com.database.lab2.controller.api;

import com.database.lab2.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
public class StudentApiController {

    private final StudentService studentService;

    @GetMapping("/student/get")
    public Boolean findId(@RequestParam String studentId) {
        return studentService.findStudentById(studentId);
    }

}
