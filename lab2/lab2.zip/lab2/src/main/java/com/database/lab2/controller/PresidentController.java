package com.database.lab2.controller;

import com.database.lab2.dto.PresidentInfo;
import com.database.lab2.dto.TeacherInfo;
import com.database.lab2.service.PresidentService;
import com.database.lab2.service.TeacherService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Controller
public class PresidentController {
    private final PresidentService presidentService;

    @GetMapping("/president/register")
    public String register(Model model){
        model.addAttribute("presidentInfo", new PresidentInfo());
        return "president/registerForm";
    }

    @PostMapping("/president/register")
    public String create(PresidentInfo presidentInfo){
        presidentService.create(presidentInfo);
        return "index";
    }

    @GetMapping("/president/list")
    public String getPresident(Model model){
        List<PresidentInfo> presidentList = presidentService.list();
        model.addAttribute("presidentList", presidentList);
        return "president/presidentList";
    }

    @PostMapping("/president/delete/{presidentId}")
    public String deletePresident(@PathVariable Long presidentId){
        presidentService.delete(presidentId);
        return "index";
    }

}
