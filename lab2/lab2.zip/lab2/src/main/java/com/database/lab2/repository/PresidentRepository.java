package com.database.lab2.repository;

import com.database.lab2.dto.PresidentInfoProjection;
import com.database.lab2.entity.President;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface PresidentRepository extends JpaRepository<President, Long> {

    @Query(nativeQuery = true,
            value ="select p.president_id as presidentId, p.president_name as presidentName," +
                    "c.college_name as collegeName from president p join college c on p.college_id = c.college_id"
    )
    List<PresidentInfoProjection> findAllPresidentInfo();
}
