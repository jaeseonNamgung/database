package com.database.lab2.dto;


public interface MajorGroupProjection {
    Integer getCount();
    String getMajorName();

}
