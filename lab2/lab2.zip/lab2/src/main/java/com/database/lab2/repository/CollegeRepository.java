package com.database.lab2.repository;

import com.database.lab2.entity.College;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CollegeRepository extends JpaRepository<College, Long> {

    College save(College college);
}
