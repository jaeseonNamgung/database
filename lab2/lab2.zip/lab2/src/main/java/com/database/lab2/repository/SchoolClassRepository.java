package com.database.lab2.repository;

import com.database.lab2.entity.SchoolClass;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SchoolClassRepository extends JpaRepository<SchoolClass, Long> {

    SchoolClass save(SchoolClass schoolClass);

}
