package com.database.lab2.service;

import com.database.lab2.dto.*;
import com.database.lab2.entity.*;
import com.database.lab2.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Transactional(readOnly = true)
@Service
public class StudentService {

    private final StudentRepository studentRepository;
    private final DormitoryRepository dormitoryRepository;
    private final MajorRepository majorRepository;
    private final SchoolClassRepository schoolClassRepository;
    private final CollegeRepository collegeRepository;



    @Transactional
    public void create(StudentInfo studentInfo) {

       Dormitory dormitory = dormitoryRepository.save(studentInfo.toDormitoryEntity());
       Major major = majorRepository.save(studentInfo.toMajorEntity());
       SchoolClass schoolClass = schoolClassRepository.save(studentInfo.toSchoolClassEntity());
       College college = collegeRepository.save(studentInfo.toCollegeEntity());
       Student s = Student.builder()
                .studentId(studentInfo.getStudentId())
                .studentName(studentInfo.getStudentName())
                .gender(studentInfo.getGender())
                .college(college)
                .major(major)
                .dormitory(dormitory)
                .schoolClass(schoolClass)
                .build();
        studentRepository.save(s);
    }

    public List<StudentInfo> list() {

        List<StudentInfoProjection> allStudentInfo = studentRepository.findAllStudentInfo();
        return allStudentInfo.stream().map(data->StudentInfo.of(
                data.getStudentId(),
                data.getStudentName(),
                data.getGender(),
                data.getClassName(),
                data.getCollegeName(),
                data.getDNumber(),
                data.getMajorName()
        )).collect(Collectors.toList());
    }


    public StudentInfo findStudent(String studentId) {

        Optional<StudentInfoProjection> allStudentInfo = studentRepository.findStudentIdProjection(studentId);
        return allStudentInfo.map(data->StudentInfo.of(
                data.getStudentId(),
                data.getStudentName(),
                data.getGender(),
                data.getClassName(),
                data.getCollegeName(),
                data.getDNumber(),
                data.getMajorName()
        )).orElse(null);
    }

    @Transactional
    public void delete(String studentId) {
        Optional<Student> student = studentRepository.findStudentById(studentId);

        Student s = student.orElse(null);
        dormitoryRepository.deleteById(s.getDormitory().getId());
        majorRepository.deleteById(s.getMajor().getId());
        schoolClassRepository.deleteById(s.getSchoolClass().getId());
        collegeRepository.deleteById(s.getCollege().getId());

    }

    public List<MajorGroupDto> majorGroup(String majorName) {
        List<MajorGroupProjection> majorGroupProjection = studentRepository.findMajorGroupBy(majorName);

        return majorGroupProjection.stream().map(
                data-> MajorGroupDto.builder()
                        .count(data.getCount())
                        .majorName(data.getMajorName())
                        .build()
        ).collect(Collectors.toList());

    }

    public List<MajorSubqueryDto> majorSubquery(String majorName) {
        List<MajorSubqueryProjection> majorSubqueryProjection = studentRepository.findMajorByStudentName(majorName);
        return majorSubqueryProjection.stream()
                .map(data->MajorSubqueryDto
                        .builder()
                        .studentId(data.getStudentId())
                        .studentName(data.getStudentName())
                        .majorName(majorName)
                        .build()
                ).collect(Collectors.toList());
    }

    public Boolean findStudentById(String studentId) {
        Optional<Student> studentById = studentRepository.findStudentById(studentId);
        return studentById.isPresent();
    }
}
