package com.database.lab2.service;

import com.database.lab2.dto.PresidentInfo;
import com.database.lab2.dto.PresidentInfoProjection;
import com.database.lab2.entity.College;
import com.database.lab2.entity.President;
import com.database.lab2.repository.CollegeRepository;
import com.database.lab2.repository.PresidentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Transactional(readOnly = true)
@RequiredArgsConstructor
@Service
public class PresidentService {

    private final PresidentRepository presidentRepository;
    private final CollegeRepository collegeRepository;

    @Transactional
    public void create(PresidentInfo presidentInfo) {
        College college =  collegeRepository.save(presidentInfo.toCollegeEntity());

        President p = President.builder()
                .presidentName(presidentInfo.getPresidentName())
                .college(college)
                .build();
        presidentRepository.save(p);
    }

    public List<PresidentInfo> list() {
        List<PresidentInfoProjection> PresidentInfoProjection = presidentRepository.findAllPresidentInfo();


        return PresidentInfoProjection.stream().map(data->
                PresidentInfo.builder()
                        .presidentId(data.getPresidentId())
                        .presidentName(data.getPresidentName())
                        .collegeName(data.getCollegeName())
                        .build()).collect(Collectors.toList()
        );
    }

    @Transactional
    public void delete(Long presidentId) {
        Optional<President> president = presidentRepository.findById(presidentId);

        President p = president.orElse(null);
        collegeRepository.deleteById(p.getCollege().getId());
    }
}
