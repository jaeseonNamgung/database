package com.database.lab2.repository;

import com.database.lab2.entity.Dormitory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DormitoryRepository extends JpaRepository<Dormitory, Long> {

    Dormitory save(Dormitory doritory);
    void deleteById(Long id);


}
