package com.database.lab2.controller;

import com.database.lab2.dto.MajorGroupDto;
import com.database.lab2.dto.MajorSubqueryDto;
import com.database.lab2.dto.StudentInfo;
import com.database.lab2.dto.StudentInfoProjection;
import com.database.lab2.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Controller
public class StudentController {
    private final StudentService studentService;

    @GetMapping("/student/register")
    public String register(Model model){
        model.addAttribute("studentInfo", new StudentInfo());
        return "student/registerForm";
    }

    @PostMapping("/student/register")
    public String create(StudentInfo studentInfo){
        studentService.create(studentInfo);
        return "index";
    }

    @GetMapping("/student/list")
    public String getStudents(Model model){
        List<StudentInfo> list = studentService.list();
        model.addAttribute("studentList", list);
        return "student/studentList";
    }

    @PostMapping("/student/delete/{studentId}")
    public String deleteStudent(@PathVariable String studentId){
        studentService.delete(studentId);
        return "index";
    }

    @GetMapping("/student/major/{majorName}")
    public String studentMajor(@PathVariable String majorName, Model model){
        List<MajorGroupDto>  list = studentService.majorGroup(majorName);
        model.addAttribute("majorList", list);
        return "/student/majorGroup";
    }
    @GetMapping("/student/major/subquery/{majorName}")
    public String majorSubquery(@PathVariable String majorName, Model model){
        List<MajorSubqueryDto>  list = studentService.majorSubquery(majorName);
        System.out.println(majorName);
        model.addAttribute("studentList", list);
        return "/student/majorSubquery";
    }


}
