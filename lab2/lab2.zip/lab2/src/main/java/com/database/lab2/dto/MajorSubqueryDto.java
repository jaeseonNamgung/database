package com.database.lab2.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MajorSubqueryDto {

    String studentId;
    String studentName;
    String majorName;

    @Builder
    public MajorSubqueryDto(String studentId, String studentName, String majorName) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.majorName = majorName;
    }
}
