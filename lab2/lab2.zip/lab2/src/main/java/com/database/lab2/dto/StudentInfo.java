package com.database.lab2.dto;

import com.database.lab2.entity.*;
import lombok.*;

@ToString
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class StudentInfo{

    private String studentId;
    private String studentName;
    private String gender;
    private String className;
    private String collegeName;
    private String dNumber;
    private String majorName;



    public static StudentInfo of(
            String studentId,
            String studentName,
            String gender,
            String className,
            String collegeName,
            String dNumber,
            String majorName

    ){
        return new StudentInfo(studentId,studentName,gender, className,collegeName, dNumber, majorName);
    }


    public Student toStudentEntity(){
        return Student.builder()
                .studentId(getStudentId())
                .studentName(getStudentName())
                .gender(getGender())
                .build();
    }
    public Dormitory toDormitoryEntity(){
        return Dormitory.builder()
                .dNumber(getDNumber())
                .build();
    }
    public College toCollegeEntity(){
        return College.builder()
                .collegeName(getCollegeName())
                .build();
    }
    public Major toMajorEntity(){
        return Major.builder()
                .majorName(getMajorName())
                .build();
    }
    public SchoolClass toSchoolClassEntity(){
        return SchoolClass.builder()
                .className(getClassName())
                .build();
    }
}
