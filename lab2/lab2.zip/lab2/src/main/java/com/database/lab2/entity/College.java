package com.database.lab2.entity;

import com.sun.istack.NotNull;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
public class College {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "COLLEGE_ID")
    private Long id;
    @Column(name = "COLLEGE_NAME", nullable = false)
    @NotNull
    private String collegeName;
    @OneToMany(mappedBy = "college", orphanRemoval = true)
    private List<Student> students = new ArrayList<>();
    @OneToMany(mappedBy = "college", orphanRemoval = true)
    private List<Teacher> teachers = new ArrayList<>();
    @OneToOne(mappedBy = "college", orphanRemoval = true)
    private President president;

    @Builder
    public College(String collegeName) {
        this.collegeName = collegeName;
    }


}
