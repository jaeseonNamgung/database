package com.database.lab2.entity;

import com.sun.istack.NotNull;
import lombok.*;

import javax.persistence.*;

@ToString
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
public class Student {

    @Id
    @Column(name = "STUDENT_ID")
    private String studentId;

    @Column(name = "STUDENT_NAME", nullable = false)
    private String studentName;

    @NotNull
    @Column(nullable = false)
    private String gender;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "class_id", nullable = false)
    private SchoolClass schoolClass;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dormitory_id", nullable = false)
    private Dormitory dormitory;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "major_id", nullable = false)
    private Major major;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "college_id", nullable = false)
    private College college;


    @Builder
    public Student(String studentId, String studentName, String gender, SchoolClass schoolClass, Dormitory dormitory, Major major, College college) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.gender = gender;
        this.schoolClass = schoolClass;
        this.dormitory = dormitory;
        this.major = major;
        this.college = college;
    }

    public Student create(String studentId, String studentName, String gender){
        return Student.builder()
                .studentId(studentId)
                .studentName(studentName)
                .gender(gender)
                .schoolClass(schoolClass)
                .dormitory(dormitory)
                .major(major)
                .college(college)
                .build();
    }


}
