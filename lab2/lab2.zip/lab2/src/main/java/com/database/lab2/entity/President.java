package com.database.lab2.entity;

import com.sun.istack.NotNull;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
public class President {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PRESIDENT_ID")
    private Long id;
    @NotNull
    @Column(name = "PRESIDENT_NAME", nullable = false)
    private String presidentName;
    @OneToOne
    @JoinColumn(name = "college_id", nullable = false)
    private College college;

    @Builder
    public President(String presidentName, College college) {
        this.presidentName = presidentName;
        this.college = college;
    }

}
