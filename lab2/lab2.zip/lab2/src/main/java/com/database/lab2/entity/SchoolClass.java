package com.database.lab2.entity;

import com.sun.istack.NotNull;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Table(name = "CLASS")
@Entity
public class SchoolClass {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CLASS_ID")
    private Long id;
    @NotNull
    @Column(name = "CLASS_NAME", nullable = false)
    private String className;
    @OneToMany(mappedBy = "schoolClass", orphanRemoval = true)
    private List<Student> students = new ArrayList<>();
    @OneToMany(mappedBy = "schoolClass", orphanRemoval = true)
    private List<Teacher> teachers = new ArrayList<>();

    @Builder
    public SchoolClass(String className) {
        this.className = className;
    }


}
