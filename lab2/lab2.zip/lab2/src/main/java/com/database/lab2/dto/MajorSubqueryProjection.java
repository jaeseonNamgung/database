package com.database.lab2.dto;

public interface MajorSubqueryProjection {
    String getStudentId();
    String getStudentName();
}
