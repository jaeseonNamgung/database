package com.database.lab2.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MajorGroupDto {
    private Integer count;
    private String majorName;

    @Builder
    public MajorGroupDto(Integer count, String majorName) {
        this.count = count;
        this.majorName = majorName;
    }
}
