package com.database.lab2.dto;

import com.database.lab2.entity.*;
import lombok.*;

@ToString
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class TeacherInfo{
    private Long teacherId;
    private String teacherName;
    private String className;
    private String courseName;
    private String collegeName;



    public static TeacherInfo of(
            Long teacherId,
            String teacherName,
            String className,
            String courseName,
            String collegeName

    ){
        return new TeacherInfo(teacherId,teacherName,className,courseName, collegeName);
    }


    public Teacher toTeacherEntity(){
        return Teacher.builder()
                .teacherName(getTeacherName())
                .build();
    }

    public SchoolClass toSchoolClassEntity(){
        return SchoolClass.builder()
                .className(getClassName())
                .build();
    }
    public College toCollegeEntity(){
        return College.builder()
                .collegeName(getCollegeName())
                .build();
    }
    public Course toCourseEntity(){
        return Course.builder()
                .courseName(getCourseName())
                .build();
    }
}
