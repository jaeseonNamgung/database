package com.database.lab2.repository;

import com.database.lab2.entity.Major;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MajorRepository extends JpaRepository<Major, Long> {
    Major save(Major major);
}
