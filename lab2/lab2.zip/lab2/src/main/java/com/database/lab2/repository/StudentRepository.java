package com.database.lab2.repository;

import com.database.lab2.dto.MajorGroupProjection;
import com.database.lab2.dto.MajorSubqueryProjection;
import com.database.lab2.dto.StudentInfo;
import com.database.lab2.dto.StudentInfoProjection;
import com.database.lab2.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {

    Student save(Student student);

    @Query(nativeQuery = true,
        value = "delete from student where student_id = :studentId"
    )
    void deleteStudentById(@Param("studentId") String studentId);

    @Query(nativeQuery = true,
            value =
                    "select student_id as studentId, student_name as studentName ,gender, class_name as className, dormitory_number as dNumber, college_name as collegeName, major_name as majorName from student s join class c on s.class_id= c.class_id join dormitory d on s.dormitory_id = d.dormitory_id  join college co on s.college_id = co.college_id join major m on s.major_id = m.major_id")
    List<StudentInfoProjection> findAllStudentInfo();


    @Query(nativeQuery = true,
            value =
                    "select student_id as studentId, student_name as studentName ,gender, " +
                            "class_name as className, dormitory_number as dNumber, " +
                            "college_name as collegeName, major_name as majorName " +
                            "from student s join class c on s.class_id= c.class_id " +
                            "join dormitory d on s.dormitory_id = d.dormitory_id  " +
                            "join college co on s.college_id = co.college_id join major m " +
                            "on s.major_id = m.major_id where s.student_id = :studentId")
    Optional<StudentInfoProjection> findStudentIdProjection(@Param("studentId") String studentId);


    @Query(nativeQuery = true,
        value = "select * from student where student_id = :studentId"
    )
    Optional<Student> findStudentById(@Param("studentId") String studentId);

    @Query(nativeQuery = true,
            value = "select count(*) as count, m.major_name as majorName from student s join major m on s.major_id = m.major_id group by m.major_name")
    List<MajorGroupProjection> findMajorGroupBy(String majorName);


    @Query(nativeQuery = true,
        value = "select student_Id as studentId, student_name as studentName from student " +
                "where major_id in(select major_id from major where major_name = :majorName)"
    )
    List<MajorSubqueryProjection> findMajorByStudentName(@Param("majorName") String majorName);
}
