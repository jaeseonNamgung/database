package com.database.lab2.entity;

import com.sun.istack.NotNull;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
public class Dormitory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DORMITORY_ID")
    private Long id;
    @NotNull
    @Column(name = "DORMITORY_NUMBER", nullable = false)
    private String dNumber;
    @OneToMany(mappedBy = "dormitory", orphanRemoval = true)
    private List<Student> students = new ArrayList<>();

    @Builder
    public Dormitory(String dNumber) {
        this.dNumber = dNumber;
    }


}
