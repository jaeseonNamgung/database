package com.database.lab2.repository;

import com.database.lab2.dto.StudentInfoProjection;
import com.database.lab2.dto.TeacherInfoProjection;
import com.database.lab2.entity.Teacher;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TeacherRepository extends JpaRepository<Teacher, Long> {

    List<Teacher> findAll();
    Teacher save(Teacher teacher);

    @Query(nativeQuery = true,
            value =
                    "select teacher_id as teacherId, teacher_name as teacherName, class_name as className,college_name as collegeName,course_name as courseName from teacher t join class c on t.class_id= c.class_id join college co on t.college_id = co.college_id join course cou on t.course_id = cou.course_id")
    List<TeacherInfoProjection> findAllTeacherInfo();



}
