package com.database.lab2.entity;

import com.sun.istack.NotNull;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
public class Major {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MAJOR_ID")
    private Long id;
    @NotNull
    @Column(name = "MAJOR_NAME", nullable = false)
    private String majorName;
    @OneToMany(mappedBy = "major", orphanRemoval = true)
    private List<Student> students = new ArrayList<>();
    @Builder
    public Major(String majorName) {
        this.majorName = majorName;
    }

}
