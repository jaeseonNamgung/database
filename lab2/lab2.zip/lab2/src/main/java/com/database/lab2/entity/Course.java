package com.database.lab2.entity;


import com.sun.istack.NotNull;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "COURSE_ID")
    private Long id;
    @NotNull
    @Column(name = "COURSE_NAME", nullable = false)
    private String courseName;
    @OneToMany(mappedBy = "course", orphanRemoval = true)
    private List<Teacher> teachers = new ArrayList<>();
    @Builder
    public Course(String courseName) {
        this.courseName = courseName;
    }

}
