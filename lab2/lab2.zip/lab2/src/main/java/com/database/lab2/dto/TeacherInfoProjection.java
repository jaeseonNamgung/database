package com.database.lab2.dto;

public interface TeacherInfoProjection {
    Long getTeacherId();
    String getTeacherName();
    String getClassName();
    String getCollegeName();
    String getCourseName();
}
