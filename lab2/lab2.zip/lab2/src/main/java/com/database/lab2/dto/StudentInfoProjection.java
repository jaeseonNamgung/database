package com.database.lab2.dto;

public interface StudentInfoProjection {

    String getStudentId();
    String getStudentName();
    String getGender();
    String getClassName();
    String getCollegeName();
    String getDNumber();
    String getMajorName();
}
