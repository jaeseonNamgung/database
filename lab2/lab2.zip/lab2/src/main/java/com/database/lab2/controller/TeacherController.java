package com.database.lab2.controller;

import com.database.lab2.dto.StudentInfo;
import com.database.lab2.dto.TeacherInfo;
import com.database.lab2.service.TeacherService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@RequiredArgsConstructor
@Controller
public class TeacherController {
    private final TeacherService teacherService;

    @GetMapping("/teacher/register")
    public String register(Model model){
        model.addAttribute("teacherInfo", new TeacherInfo());
        return "teacher/registerForm";
    }

    @PostMapping("/teacher/register")
    public String create(TeacherInfo teacherInfo){
        teacherService.create(teacherInfo);
        return "index";
    }

    @GetMapping("/teacher/list")
    public String getStudents(Model model){
        List<TeacherInfo> list = teacherService.list();
        model.addAttribute("teacherList", list);
        return "teacher/teacherList";
    }

    @PostMapping("/teacher/delete/{teacherId}")
    public String deleteTeacher(@PathVariable Long teacherId){
        teacherService.delete(teacherId);
        return "index";
    }

}
