package com.database.lab2.service;

import com.database.lab2.dto.StudentInfo;
import com.database.lab2.dto.StudentInfoProjection;
import com.database.lab2.dto.TeacherInfo;
import com.database.lab2.dto.TeacherInfoProjection;
import com.database.lab2.entity.*;
import com.database.lab2.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Transactional(readOnly = true)
@Service
public class TeacherService {

    private final TeacherRepository teacherRepository;
    private final SchoolClassRepository schoolClassRepository;
    private final CollegeRepository collegeRepository;
    private final CourseRepository courseRepository;

    @Transactional
    public void create(TeacherInfo teacherInfo) {
        SchoolClass schoolClass = schoolClassRepository.save(teacherInfo.toSchoolClassEntity());
        College college = collegeRepository.save(teacherInfo.toCollegeEntity());
        Course course =  courseRepository.save(teacherInfo.toCourseEntity());

        Teacher t = Teacher.builder()
                .teacherName(teacherInfo.getTeacherName())
                .college(college)
                .schoolClass(schoolClass)
                .course(course)
                .build();
        teacherRepository.save(t);
    }

    public List<TeacherInfo> list() {
        List<TeacherInfoProjection> allTeacherInfo = teacherRepository.findAllTeacherInfo();
        return allTeacherInfo.stream().map(data->TeacherInfo.of(
                data.getTeacherId(),
                data.getTeacherName(),
                data.getClassName(),
                data.getCourseName(),
                data.getCollegeName()
        )).collect(Collectors.toList());
    }

    @Transactional
    public void delete(Long teacherId) {
        Optional<Teacher> teacher = teacherRepository.findById(teacherId);

        Teacher t = teacher.orElse(null);
        schoolClassRepository.deleteById(t.getSchoolClass().getId());
        collegeRepository.deleteById(t.getCollege().getId());
        courseRepository.deleteById(t.getCourse().getId());
    }
}
