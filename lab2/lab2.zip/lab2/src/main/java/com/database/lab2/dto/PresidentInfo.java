package com.database.lab2.dto;

import com.database.lab2.entity.College;
import com.database.lab2.entity.President;
import lombok.*;

@NoArgsConstructor
@Getter
@Setter
public class PresidentInfo {

    private Long presidentId;
    private String presidentName;
    private String collegeName;

    @Builder
    public PresidentInfo(Long presidentId, String presidentName, String collegeName) {
        this.presidentId = presidentId;
        this.presidentName = presidentName;
        this.collegeName = collegeName;
    }

    public President toPresidentEntity(){
        return President.builder()
                .presidentName(presidentName)
                .build();
    }

    public College toCollegeEntity(){
        return College.builder()
                .collegeName(getCollegeName())
                .build();
    }
}
