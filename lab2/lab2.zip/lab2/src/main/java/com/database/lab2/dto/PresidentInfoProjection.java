package com.database.lab2.dto;

public interface PresidentInfoProjection {

    Long getPresidentId();
    String getPresidentName();
    String getCollegeName();
}
